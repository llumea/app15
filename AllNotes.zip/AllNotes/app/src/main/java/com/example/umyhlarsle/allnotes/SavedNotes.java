package com.example.umyhlarsle.allnotes;

import java.util.ArrayList;

/**
 * Created by umyhlarsle on 2016-01-04.
 */
public class SavedNotes {

    ArrayList<ToDoNote> myToDoNotes = new ArrayList<>();
    ArrayList<TextNote> myTextNotes = new ArrayList<>();

    public SavedNotes(){

    }
}
