package com.example.umyhlarsle.allnotes;

/**
 * Created by umyhlarsle on 2015-12-16.
 */
public class Tag {

    String content;

    public Tag(){

    }
}
